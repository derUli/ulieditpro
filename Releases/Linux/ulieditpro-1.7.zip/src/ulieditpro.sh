#!/bin/bash
python /opt/ulieditpro/main.py $1 $2
